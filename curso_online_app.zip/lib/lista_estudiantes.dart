
import 'package:flutter/material.dart';
import 'db_helper.dart';

class ListaEstudiantes extends StatefulWidget {
  @override
  _ListaEstudiantesState createState() => _ListaEstudiantesState();
}

class _ListaEstudiantesState extends State<ListaEstudiantes> {
  List<Map<String, dynamic>> _estudiantes = [];

  @override
  void initState() {
    super.initState();
    _cargarEstudiantes();
  }

  Future<void> _cargarEstudiantes() async {
    final data = await DatabaseHelper().obtenerEstudiantes();
    setState(() {
      _estudiantes = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Lista de Estudiantes')),
      body: ListView.builder(
        itemCount: _estudiantes.length,
        itemBuilder: (context, index) {
          final estudiante = _estudiantes[index];
          return ListTile(
            title: Text(estudiante['nombre']),
            subtitle: Text('DNI: ${estudiante['dni']} - Cuota: ${estudiante['cuota'].toStringAsFixed(2)}'),
          );
        },
      ),
    );
  }
}
