
import 'package:flutter/material.dart';
import 'registro_estudiante.dart';

class LoginPage extends StatelessWidget {
  final TextEditingController userController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  void _validateLogin(BuildContext context) {
    if (userController.text == 'admin' && passController.text == '1234') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => RegistroEstudiante()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Usuario o contraseña incorrectos')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 50),
          Center(child: Image.asset('assets/logo.png', height: 100)),
          Text('Autenticación',
              style: TextStyle(fontSize: 20, color: Colors.red),
              textAlign: TextAlign.center),
          TextField(controller: userController, decoration: InputDecoration(labelText: 'Usuario')),
          TextField(controller: passController, obscureText: true, decoration: InputDecoration(labelText: 'Contraseña')),
          ElevatedButton(onPressed: () => _validateLogin(context), child: Text('Ingresar')),
        ],
      ),
    );
  }
}
