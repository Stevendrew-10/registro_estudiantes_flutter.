
import 'package:flutter/material.dart';

class RegistroEstudiante extends StatefulWidget {
  @override
  _RegistroEstudianteState createState() => _RegistroEstudianteState();
}

class _RegistroEstudianteState extends State<RegistroEstudiante> {
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController dniController = TextEditingController();
  final TextEditingController montoInicialController = TextEditingController();

  double cuota = 0.0;

  void _calcularCuotas() {
    final inicial = double.tryParse(montoInicialController.text) ?? 0;
    final restante = 1500 - inicial;
    final cuotaBase = restante / 4;
    cuota = cuotaBase + (cuotaBase * 0.05);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Registro de estudiantes', style: TextStyle(fontSize: 15, color: Colors.blue))),
      body: Column(
        children: [
          TextField(controller: nombreController, decoration: InputDecoration(labelText: 'Nombre')),
          TextField(controller: dniController, decoration: InputDecoration(labelText: 'DNI')),
          TextField(controller: montoInicialController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Monto inicial')),
          ElevatedButton(onPressed: _calcularCuotas, child: Text('Calcular cuotas')),
          if (cuota > 0)
            Text('Cada cuota: ${cuota.toStringAsFixed(2)}'),
        ],
      ),
    );
  }
}
